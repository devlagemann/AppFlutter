import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primaryColor: Color(0xFF4CAF50),
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  TextEditingController _addController = TextEditingController();
  TextEditingController _subtractController = TextEditingController();

  double soma = 0.0;

  // Função para adicionar um valor à soma
  void _addValue() {
    double value = double.tryParse(_addController.text) ?? 0.0;
    setState(() {
      soma += value;
      _addController.clear(); // Limpa o campo de adição
    });
  }

  // Função para subtrair um valor da soma
  void _subtractValue() {
    double value = double.tryParse(_subtractController.text) ?? 0.0;

    // Verifica se o valor a ser subtraído não é maior do que o valor acumulado
    if (value > soma) {
      _showErrorMessage('O valor a ser subtraído não pode ser maior que o valor acumulado!');
    } else {
      setState(() {
        soma -= value;
        _subtractController.clear(); // Limpa o campo de subtração
      });
    }
  }

  // Função para exibir uma mensagem de erro
  void _showErrorMessage(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Erro'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Fecha o diálogo
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'Cofrinho Online',
          style: TextStyle(
            color: Colors.white70,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Color(0xFF4CAF50), // Cor verde semelhante ao Sicredi
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Título informando o que o usuário pode fazer
            Text(
              'Cofrinho Online',
              style: TextStyle(
                fontSize: 20,
                color: Colors.white,
                fontWeight: FontWeight.w900,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 30),

            // Campo de texto para adicionar valor
            TextField(
              controller: _addController,
              decoration: InputDecoration(
                labelText: 'Valor para adicionar ao seu tesouro',
                labelStyle: TextStyle(color: Color(0xFF4CAF50)),
                border: OutlineInputBorder(),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFF4CAF50), width: 2.0),
                ),
                prefixIcon: Icon(Icons.add, color: Color(0xFF4CAF50)),
              ),
              keyboardType: TextInputType.numberWithOptions(decimal: true),
            ),
            SizedBox(height: 20),
            // Botão para adicionar o valor
            ElevatedButton(
              onPressed: _addValue,
              style: ElevatedButton.styleFrom(
                primary: Color(0xFF4CAF50), // Cor do botão
                padding: EdgeInsets.symmetric(vertical: 16),
              ),
              child: Text(
                'Adicionar',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(height: 30),

            // Campo de texto para subtrair valor
            TextField(
              controller: _subtractController,
              decoration: InputDecoration(
                labelText: 'Valor para subtrair ao seu tesouro',
                labelStyle: TextStyle(color: Color(0xFF4CAF50)),
                border: OutlineInputBorder(),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFF4CAF50), width: 2.0),
                ),
                prefixIcon: Icon(Icons.remove, color: Color(0xFF4CAF50)),
              ),
              keyboardType: TextInputType.numberWithOptions(decimal: true),
            ),
            SizedBox(height: 20),
            // Botão para subtrair o valor
            ElevatedButton(
              onPressed: _subtractValue,
              style: ElevatedButton.styleFrom(
                primary: Color(0xFF4CAF50), // Cor do botão
                padding: EdgeInsets.symmetric(vertical: 16),
              ),
              child: Text(
                'Subtrair',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(height: 30),

            // Exibição do valor acumulado
            Text(
              'Soma acumulada: R\$ $soma',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Color(0xFF4CAF50),
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
